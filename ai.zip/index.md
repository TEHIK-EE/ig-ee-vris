# Home - VRIS - Viljatusravi infosüsteem v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://fhir.ee/vris/ImplementationGuide/ee.fhir.vris | *Version*:0.1.0 |
| Draft as of 2026-08-26 | *Computable Name*:EEVRIS |

> 

# NB! This is a development build and should be considered as “work in progress”. The content changes on a daily basis. This is not an official product release yet.

# Juhendit täiendatakse igapäevaselt. Kõik liidestumiseks vajalik materjal pole veel juhendisse lisatud, tegu on MUSTANDIGA!

# NB! SNOMED koodid on enamjaolt placeholderid. KÕIK tuleb üle kontrollida! Loendite viited on kunstlikud, loendid on alles loomisel.


### Intro

Viljatusravi infosüsteemi IG.

#### Source code

This IG source code is available in [GitHub](https://github.com/TEHIK-EE/ig-ee-vris).

### How to start

Building and deploying information is located in [GitHub](https://github.com/TEHIK-EE/ig-ee-vris) project [README](https://github.com/TEHIK-EE/ig-ee-vris/blob/main/README.md) file.

