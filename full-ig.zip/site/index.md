# Home - VRIS - Viljatusravi infosüsteem v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://fhir.ee/vris/ImplementationGuide/ee.fhir.vris | *Version*:0.1.0 |
| Draft as of 2026-11-03 | *Computable Name*:EEVRIS |

> 

# NB! This is a development build and should be considered as “work in progress”. The content changes on a daily basis. This is not an official product release yet.

# Juhendit täiendatakse igapäevaselt. Kõik liidestumiseks vajalik materjal pole veel juhendisse lisatud, tegu on MUSTANDIGA!

### NB! SNOMED koodid on enamjaolt placeholderid. KÕIK tuleb üle kontrollida! Loendite viited on kunstlikud, loendid on alles loomisel.


##### Intro

Viljatusravi infosüsteemi IG.

###### Source code

This IG source code is available in [GitHub](https://github.com/TEHIK-EE/ig-ee-vris).

##### How to start

Building and deploying information is located in [GitHub](https://github.com/TEHIK-EE/ig-ee-vris) project [README](https://github.com/TEHIK-EE/ig-ee-vris/blob/main/README.md) file.



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "ee.fhir.vris",
  "url" : "https://fhir.ee/vris/ImplementationGuide/ee.fhir.vris",
  "version" : "0.1.0",
  "name" : "EEVRIS",
  "title" : "VRIS - Viljatusravi infosüsteem",
  "status" : "draft",
  "date" : "2026-11-03T14:02:45+00:00",
  "publisher" : "TEHIK",
  "contact" : [{
    "name" : "TEHIK",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.tehik.ee"
    },
    {
      "system" : "email",
      "value" : "fhir@tehik.ee"
    }]
  },
  {
    "name" : "TEHIK Andmekorraldus",
    "telecom" : [{
      "system" : "email",
      "value" : "andmekorraldus@tehik.ee",
      "use" : "work"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "EE",
      "display" : "Estonia"
    }]
  }],
  "packageId" : "ee.fhir.vris",
  "license" : "MIT",
  "fhirVersion" : ["5.0.0"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r5",
    "version" : "7.5.0"
  },
  {
    "id" : "hl7_fhir_uv_extensions",
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions",
    "version" : "current"
  },
  {
    "id" : "ee_fhir_base",
    "uri" : "https://fhir.ee/base/ImplementationGuide/ee.fhir.base",
    "packageId" : "ee.fhir.base",
    "version" : "2.0.0"
  },
  {
    "id" : "ee_fhir_mpi",
    "uri" : "https://fhir.ee/mpi/ImplementationGuide/ee.fhir.mpi",
    "packageId" : "ee.fhir.mpi",
    "version" : "1.5.0"
  }],
  "definition" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r5#1.3.0"
    }],
    "grouping" : [{
      "id" : "GroupA",
      "name" : "Persons",
      "description" : "Donor-Recipient related profiles"
    },
    {
      "id" : "GroupB",
      "name" : "Biological material",
      "description" : "Embryo and reproductive cell profiles"
    },
    {
      "id" : "GroupC",
      "name" : "Observations",
      "description" : "Observation profiles"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "OperationDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "OperationDefinition-EEVRISPatientObservations.html"
      }],
      "reference" : {
        "reference" : "OperationDefinition/EEVRISPatientObservations"
      },
      "name" : "$patient-observations operation",
      "description" : "TEST Custom operation to retrieve all Observation resources for a specific patient in Estonian VRIS. Supports optional filtering by profile, category, code, and date range. (ee TEST Operatioon kõikide Observation ressursside pärimiseks VRIS-ist. Tagastab Bundle'i kõikide Observationitega, kus subject viitab antud patsiendile.)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-additional-identifier.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-additional-identifier"
      },
      "name" : "Additional identifier",
      "description" : "Extension for additional identifier. (ee Lisa-identifikaator)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-allocation-oocyte1-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/allocation-oocyte1-1"
      },
      "name" : "allocation-oocyte1-1",
      "description" : "Allocation of oocyte to IVF cycle",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-procedure-allocation"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-allocation-sperm1-3.html"
      }],
      "reference" : {
        "reference" : "Procedure/allocation-sperm1-3"
      },
      "name" : "allocation-sperm1-3",
      "description" : "Cancelled allocation - material released back to available",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-procedure-allocation"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-embryo.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-embryo"
      },
      "name" : "BiologicallyDerivedProduct: EE VRIS Embryo",
      "description" : "Profile for embryo. (ee Embrüo. Iga embrüo on omaette BDP-ressurss, mis kannab enda andmeid (arengupäev, parent-viited munarakule ja spermale). Füüsiline pakend (kõrs) on eraldi BDP-instants, mis kannab division-i ja säilitusandmeid (preservationState, temperatuur, sulatamine, taaskülmutamine). )",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-oocyte.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-oocyte"
      },
      "name" : "BiologicallyDerivedProduct: EE VRIS Oocyte",
      "description" : "Profile for oocyte. (ee Bioloogiline materjal (munarakk/munarakud)",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-reproductive-tissue.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-reproductive-tissue"
      },
      "name" : "BiologicallyDerivedProduct: EE VRIS Reproductive Tissue",
      "description" : "Profile for reproductive tissue (testicular tissue, ovarian tissue). Used mainly for fertility preservation. (ee Bioloogiline materjal (munandi kude, munasarja kude). Kasutatakse peamiselt viljakuse säilitamiseks.)",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-sperm.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-sperm"
      },
      "name" : "BiologicallyDerivedProduct: EE VRIS Sperm",
      "description" : "Profile for sperm. (ee Bioloogiline materjal (Seemnerakud)",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-birth-sex.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-birth-sex"
      },
      "name" : "Birth Sex",
      "description" : "Extension for birth sex. (ee Sünnisugu)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-care-plan.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-care-plan"
      },
      "name" : "CarePlan: EEVRIS Cycle",
      "description" : "Profile for capturing infertility treatment. (ee Ravisükklit koondav profiil. Võib olla VÄRSKE või KÜLMUTATUD-SULATATUD)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-role.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-role"
      },
      "name" : "Cell origin role",
      "description" : "Extension for the role of donor/recipient of biological material. (ee Sperma/munaraku doonori/retsipiendi roll (viljatusravi saav naine, mittepartnerannetaja, partner, anonüümne, säilitaja jne).)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-cell-preservation-reason.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-cell-preservation-reason"
      },
      "name" : "Cell preservation reason",
      "description" : "Extension for the reason of cell preservation. (ee VILJAKUSE (Sperma/munaraku jne) säilitamise põhjus. Nt meditsiiniline, mittemeditsiiniline jne.)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-condition-birth-defect.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-condition-birth-defect"
      },
      "name" : "Condition: EE VRIS Birth Defect",
      "description" : "Congenital birth defect of newborn child. (ee Lapse väärarend. NB! Tulevikus kasutada diagnoosi-teenuse viidet!)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-cause-of-death.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-cause-of-death"
      },
      "name" : "Condition: EE VRIS Cause of Death",
      "description" : "Profile for capturing cause and time of death. (ee Surma põhjus. NB! Tulevikus kasutada diagnoosi-teenuse viidet!)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-condition-comorbidity.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-condition-comorbidity"
      },
      "name" : "Condition: EE VRIS Comorbidity",
      "description" : "Condition profile for comorbidities of a donor or recipient in the Estonian VRIS fertility system. (ee Kaasuv haigus. NB! Tulevikus viidata Diagnoosi-teenusele!)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-condition-pregnancy.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-condition-pregnancy"
      },
      "name" : "Condition: EE VRIS Condition Pregnancy",
      "description" : "Condition profile for pregnancy in Estonian VRIS fertility system. (ee Rasedus kui näidustus, diagnoos. NB! Tulevikus viidata Diagnoosi-teenusele!)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-condition-donor-genetic-finding.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-condition-donor-genetic-finding"
      },
      "name" : "Condition: EE VRIS Donor Genetic Finding",
      "description" : "Genetic finding of cell donor that appears later in life. (ee Tagantjärgi ilmnenud doonori geneetiline haigus või kandlus. NB! Tulevikus viidata Diagnoosi-teenusele!)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-condition-fertility-indication-female.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-condition-fertility-indication-female"
      },
      "name" : "Condition: EE VRIS Female Fertility Treatment Indication",
      "description" : "Clinical indication or diagnosis that is the reason for infertility treatment for Female. (ee NAISE kunstliku viljastamise näidustus, kliiniline diagnoos või seisund, mis on viljatusravi põhjus. NB! Tulevikus viidata Diagnoosi-teenusele!)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-condition-treatment-complication.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-condition-treatment-complication"
      },
      "name" : "Condition: EE VRIS Fertility Treatment Complication",
      "description" : "Complication related to fertility treatment. (ee Viljatusraviga seotud (haiglaravi vajavad?) tüsistused. NB! Tulevikus kasutada diagnoosi-teenuse viidet!)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-condition-fertility-indication-etiology-male.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-condition-fertility-indication-etiology-male"
      },
      "name" : "Condition: EE VRIS Male Fertility Etiology Indication",
      "description" : "Etiological cause of male infertility. (ee MEHE viljatuse etioloogiline põhjus. NB! Tulevikus viidata Diagnoosi-teenusele!)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-condition-fertility-indication-male.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-condition-fertility-indication-male"
      },
      "name" : "Condition: EE VRIS Male Fertility Treatment Indication",
      "description" : "Clinical indication or diagnosis that is the reason for infertility treatment for Male. (ee FENOTÜÜP. MEHEpoolne kunstliku viljastamise näidustus, kliiniline diagnoos või seisund, mis on viljatusravi põhjus. NB! Tulevikus viidata Diagnoosi-teenusele!)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-terk-coverage.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-terk-coverage"
      },
      "name" : "Coverage",
      "description" : "Extension for Tervisekassa coverage existence. (ee Kas (teenusel/ravil/tsüklil/vm on/ei ole Tervisekassa poolset kompensatsiooni patsiendile.)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-cryopreservation-date.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-cryopreservation-date"
      },
      "name" : "Cryopreservation date",
      "description" : "Extension for cryopreservation date. (ee Bioloogilise materjali külmutamise (krüopreservatsiooni) kuupäev.)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-cycle-discontinuation-reason.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-cycle-discontinuation-reason"
      },
      "name" : "Cycle Discontinuation Reason",
      "description" : "Reason for fertility treatment cycle discontinuation. (ee Ravitsükli katkestamise põhjus.)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-donor-genetic-finding-suspected1.html"
      }],
      "reference" : {
        "reference" : "Condition/donor-genetic-finding-suspected1"
      },
      "name" : "donor-genetic-finding-suspected1",
      "description" : "Example of suspected condition of genetic disorder of donor",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-condition-donor-genetic-finding"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-donor-genetic-finding-verified1.html"
      }],
      "reference" : {
        "reference" : "Condition/donor-genetic-finding-verified1"
      },
      "name" : "donor-genetic-finding-verified1",
      "description" : "Example of confirmed condition of donor's genetic disorder",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-condition-donor-genetic-finding"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "BiologicallyDerivedProduct"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "BiologicallyDerivedProduct-embryo1.html"
      }],
      "reference" : {
        "reference" : "BiologicallyDerivedProduct/embryo1"
      },
      "name" : "embryo1",
      "description" : "Package 1 of 2. Cryopreserved, contains two embryos",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-embryo"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "BiologicallyDerivedProduct"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "BiologicallyDerivedProduct-embryo1-1.html"
      }],
      "reference" : {
        "reference" : "BiologicallyDerivedProduct/embryo1-1"
      },
      "name" : "embryo1-1",
      "description" : "Individual embryo 1 in package EMB789-1",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-embryo"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "BiologicallyDerivedProduct"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "BiologicallyDerivedProduct-embryo1-2.html"
      }],
      "reference" : {
        "reference" : "BiologicallyDerivedProduct/embryo1-2"
      },
      "name" : "embryo1-2",
      "description" : "Individual embryo 2 in package EMB789-1",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-embryo"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "BiologicallyDerivedProduct"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "BiologicallyDerivedProduct-embryo2.html"
      }],
      "reference" : {
        "reference" : "BiologicallyDerivedProduct/embryo2"
      },
      "name" : "embryo2",
      "description" : "Fresh package. Transferred in the same cycle (Värske)",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-embryo"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "BiologicallyDerivedProduct"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "BiologicallyDerivedProduct-embryo2-1.html"
      }],
      "reference" : {
        "reference" : "BiologicallyDerivedProduct/embryo2-1"
      },
      "name" : "embryo2-1",
      "description" : "Individual embryo in fresh package EMB790-1",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-embryo"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-encounter-donationSperm2025.html"
      }],
      "reference" : {
        "reference" : "Encounter/encounter-donationSperm2025"
      },
      "name" : "encounter-donationSperm2025",
      "description" : "Visit. Sperm collection and cryopreservation",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-encounter"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-encounter.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-encounter"
      },
      "name" : "Encounter: EE VRIS Encounter",
      "description" : "Simple encounter profile for VRIS fertility treatment visits. (ee Visiidi ehk KONTAKTI profiil viljatusravi kontekstis. NB! Tulevikus tuleb viidata Encounter-EoC teenusele!)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "EpisodeOfCare"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "EpisodeOfCare-eoc-donationSperm2025.html"
      }],
      "reference" : {
        "reference" : "EpisodeOfCare/eoc-donationSperm2025"
      },
      "name" : "eoc-donationSperm2025",
      "description" : "Example of donation event as a whole. Sperm donation to partner. (ee Doonorluse sündmus, mis koondab kokku kõik visiitide käigus tehtud protseduurid jm)",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-episode-of-care"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-episode-of-care.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-episode-of-care"
      },
      "name" : "EpisodeOfCare: EE VRIS Episode of Care",
      "description" : "Episode of care profile for VRIS fertility treatment. Groups related encounters, procedures and observations within a longer treatment period. (ee Viljatusravi episood (näiteks doonorluse sündmus) ühendab ravitsükli piires toimuvad visiidid (Encounter), protseduurid ja vaatlused. NB! Tulevikus viidata Encounter-Episode teenusele!)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-episode-of-care-pregnancy.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-episode-of-care-pregnancy"
      },
      "name" : "EpisodeOfCare: EE VRIS EpisodeOfCare Pregnancy",
      "description" : "EpisodeOfCare profile for the WHOLE pregnancy, starting before conception and ending with childbirth. (ee Raseduse kogu elukaar. NB! Profiil peab järgima Encounter-EoC tuleviku struktuuri!).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-female-fertility-indication-example1.html"
      }],
      "reference" : {
        "reference" : "Condition/female-fertility-indication-example1"
      },
      "name" : "female-fertility-indication-example1",
      "description" : "Example of a female fertility treatment indication: anovulation disorder (ICD-10: N97.0).",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-condition-fertility-indication-female"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-fertility-preservation-method.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-fertility-preservation-method"
      },
      "name" : "Fertility Preservation Method",
      "description" : "Method for fertility preservation why biological material is being preserved. (ee Viljakuse säilitamise meetod. (Nt  Puberteedieelne munasarja koe säilitamine))",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CarePlan-carePlanIvfCycle2025.html"
      }],
      "reference" : {
        "reference" : "CarePlan/carePlanIvfCycle2025"
      },
      "name" : "IVF tsükkel #1 Märts 2025",
      "description" : "Example of a fresh IVF treatment cycle CarePlan for female recipient.",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-care-plan"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-medication-administration.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-medication-administration"
      },
      "name" : "MedicationAdministration: EE VRIS Medication administred during procedure(s)",
      "description" : "Profile for medication administration during infertility procedure(s). (ee Viljatusravi ajal manustatud ravim(id).)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-medicationAdministrationFollitropin1.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/medicationAdministrationFollitropin1"
      },
      "name" : "medicationAdministrationFollitropin1",
      "description" : "Example of follitropin administration during ovarian stimulation for IVF cycle",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-medication-administration"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-observation-bloodgroup.html"
      }],
      "reference" : {
        "reference" : "Observation/observation-bloodgroup"
      },
      "name" : "observation-bloodgroup",
      "description" : "Example of bloodgroup",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-observation-blood-group"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-observation-embryo-lifecycle-counts.html"
      }],
      "reference" : {
        "reference" : "Observation/observation-embryo-lifecycle-counts"
      },
      "name" : "observation-embryo-lifecycle-counts",
      "description" : "Example of embryo lifecycle counts summary for IVF cycle",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-observation-embryo-lifecycle-counts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-attempting-to-concieve.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-attempting-to-concieve"
      },
      "name" : "Observation: EE VRIS Attempting to Concieve",
      "description" : "Observation profile for how long is woman attempting to concieve. (ee Rasestuda üritamine.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-biochemical-pregnancy.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-biochemical-pregnancy"
      },
      "name" : "Observation: EE VRIS Biochemical Pregnancy",
      "description" : "Biochemical pregnancy detected by blood test. (ee Biokeemiline rasedus, tuvastatud vereanalüüsiga.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-birth-weight.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-birth-weight"
      },
      "name" : "Observation: EE VRIS Birth Weight",
      "description" : "Birth weight of newborn child. (ee Lapse sünnikaal grammides.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-blood-group.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-blood-group"
      },
      "name" : "Observation: EE VRIS Blood Group",
      "description" : "Observation profile for recording the ABO and Rh(D) blood group in the Estonian VRIS fertility system. (ee Veregrupp.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-child-count.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-child-count"
      },
      "name" : "Observation: EE VRIS Child Count",
      "description" : "Count of children/pregnancies fom one donor. (ee Ühe anonüümse või mittepartnerist doonori doonorrakkudest saadud raseduste ja sündinud laste arv ning nende naiste arv, kellel on säilitatud embrüoid, mis on loodud nimetatud doonori doonorrakkudest ja mida võidakse tulevikus kasutada raseduse saavutamiseks.)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-clinical-pregnancy.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-clinical-pregnancy"
      },
      "name" : "Observation: EE VRIS Clinical Pregnancy",
      "description" : "Clinical pregnancy, confirmed by ultrasound AND number of fetus. (ee Kliiniline rasedus, kinnitatud ultraheliuuringuga. LOOTEMUNADE arv ka! NB! Biokeemilise raseduse profiil on eraldi.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-education-level.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-education-level"
      },
      "name" : "Observation: EE VRIS Education Level",
      "description" : "Education level of a donor or recipient in the Estonian VRIS fertility system. (ee Haridustase. NB! Pärimisel kasutada MPI profiili, sisestamisel või kui patsienti pole rahvastikuregistris, kasuta VRIS profiili.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-embryo-lifecycle-counts.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-embryo-lifecycle-counts"
      },
      "name" : "Observation: EE VRIS Embryo Lifecycle Counts",
      "description" : "Summary counts of embryo lifecycle events in a fertility treatment cycle (frozen, transferred, destroyed). (ee Embrüote elutsükli kokkuvõtted: külmutatud, siirdatud, hävitatud arv tsüklis. NB! Koodid pole veel kinnitatud)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-fertilization-counts.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-fertilization-counts"
      },
      "name" : "Observation: EE VRIS Fertilization Counts",
      "description" : "Counts of oocytes used and fertilized during fertilization procedure. (ee Viljastamise protseduuri munarakkude arvud erinevates staadiumites. NB! koodid pole veel lõplikult kinnitatud!)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-fetus-reduction.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-fetus-reduction"
      },
      "name" : "Observation: EE VRIS Fetus Reduction",
      "description" : "Observation profile for recording whether fetus reduction procedure was performed in multifetal pregnancy. (ee Loote/loodete reduktsiooni läbiviimine mitmikrasedusel.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-height.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-height"
      },
      "name" : "Observation: EE VRIS Height",
      "description" : "Observation profile for recording height of a donor in the Estonian VRIS fertility system. (ee Pikkus.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-live-births.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-live-births"
      },
      "name" : "Observation: EE VRIS Live Births",
      "description" : "Live births and stillbirths BEFORE current treatment. (ee Elusalt sündinud laste arv ENNE käesolevat viljatusravi tsüklit.)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-marital-status.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-marital-status"
      },
      "name" : "Observation: EE VRIS Marital Status",
      "description" : "Marital status of a donor or recipient in the Estonian VRIS fertility system. (ee Perekonnaseis. NB! Pärimisel kasutada MPI profiili, sisestamisel või kui patsienti pole rahvastikuregistris, kasuta VRIS profiili.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-neonatal-intensive-care.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-neonatal-intensive-care"
      },
      "name" : "Observation: EE VRIS Neonatal Intensive Care",
      "description" : "Whether the child received neonatal intensive care during first 7 days of life. (ee Lapse intensiivravi esimese 7 elupäeva jooksul.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-obstetric-history.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-obstetric-history"
      },
      "name" : "Observation: EE VRIS Obstetric History",
      "description" : "Past obstetric history at the START of fertility treatment cycle. Records cumulative count of all prior pregnancies, deliveries, live births and stillbirths BEFORE current treatment. (ee Sünnitusanamnees ENNE käesolevat viljatusravi tsüklit. Varasemate raseduste, sünnituste ja sündide kumulatiivne arv.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-stimulation-protocol.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-stimulation-protocol"
      },
      "name" : "Observation: EE VRIS Ovarian Stimulation Protocol",
      "description" : "Captures ovarian stimulation protocol details for fertility treatment cycle. (ee Munasarjade stimulatsiooni protokoll sisaldab meetodi, supressiooni, gonadotropiini ja eelneva ravi info.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-physical-appearance.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-physical-appearance"
      },
      "name" : "Observation: EE VRIS Physical Appearance",
      "description" : "Observation profile for recording characteristics of physical appearance of donor. (ee Profiil on mõeldud välimust kirjeldavate karakteristikute jaoks, nt silmade värd, juuste värv, naha värv, kehaehitus.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-pregnancy-outcome.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-pregnancy-outcome"
      },
      "name" : "Observation: EE VRIS Pregnancy Outcome",
      "description" : "Pregnancy outcome including delivery, miscarriage, abortion details. (ee Raseduse lõpe sünnitus, katkemine või katkestamine koos detailidega.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-prenatal-care-discontinued.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-prenatal-care-discontinued"
      },
      "name" : "Observation: EE VRIS Prenatal Care Discontinued",
      "description" : "Indicator whether prenatal care was discontinued by patient or for unknown reasons. (ee Rasedusaegne tervisekontroll katkestatud patsiendi poolt või teadmata põhjusel.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-prior-fertility-treatment.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-prior-fertility-treatment"
      },
      "name" : "Observation: EE VRIS Prior Fertility Treatment",
      "description" : "Prior fertility treatment history. Records whether IVF and/or IUI has been performed and the number of cycles. (ee Varasema viljatusravi anamnees)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-stimulation-protocol-embryo.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-stimulation-protocol-embryo"
      },
      "name" : "Observation: EE VRIS Stimulation Protocol for Embryo Transfer",
      "description" : "Captures stimulation protocol details for thawed embryo. (ee Sulatatud embrüo siirdamise protokoll jm.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-tobacco-use.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-tobacco-use"
      },
      "name" : "Observation: EE VRIS Tobacco Use",
      "description" : "Observation profile for tobacco use status in the Estonian VRIS fertility system. (ee Tubakatoodete kasutamine.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-waist.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-waist"
      },
      "name" : "Observation: EE VRIS Waist",
      "description" : "Observation profile for recording waist circumference of a donor in the Estonian VRIS fertility system. (ee Vööümbermõõt.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-observation-weight.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-observation-weight"
      },
      "name" : "Observation: EE VRIS Weight",
      "description" : "Observation profile for recording weight of a donor in the Estonian VRIS fertility system. (ee Kaal.)",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "BiologicallyDerivedProduct"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "BiologicallyDerivedProduct-oocyte1.html"
      }],
      "reference" : {
        "reference" : "BiologicallyDerivedProduct/oocyte1"
      },
      "name" : "oocyte1",
      "description" : "Example of oocyte",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-oocyte"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "BiologicallyDerivedProduct"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "BiologicallyDerivedProduct-oocyte1-1.html"
      }],
      "reference" : {
        "reference" : "BiologicallyDerivedProduct/oocyte1-1"
      },
      "name" : "oocyte1-1",
      "description" : "Package 1 of 3 - used fresh",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-oocyte"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "BiologicallyDerivedProduct"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "BiologicallyDerivedProduct-oocyte1-2.html"
      }],
      "reference" : {
        "reference" : "BiologicallyDerivedProduct/oocyte1-2"
      },
      "name" : "oocyte1-2",
      "description" : "Package 2 of 3 - cryopreserved, in storage",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-oocyte"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "BiologicallyDerivedProduct"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "BiologicallyDerivedProduct-oocyte1-3.html"
      }],
      "reference" : {
        "reference" : "BiologicallyDerivedProduct/oocyte1-3"
      },
      "name" : "oocyte1-3",
      "description" : "Package 3 of 3 - cryopreserved, thawed and used",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-oocyte"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-organization-novavita1.html"
      }],
      "reference" : {
        "reference" : "Organization/organization-novavita1"
      },
      "name" : "organization-novavita1",
      "description" : "Example Organization. (ee Näidis-Asutus. NB! Hiljem tuleb vahetada SPD vastu!)",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "BiologicallyDerivedProduct"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "BiologicallyDerivedProduct-ovariantissue1.html"
      }],
      "reference" : {
        "reference" : "BiologicallyDerivedProduct/ovariantissue1"
      },
      "name" : "ovariantissue1",
      "description" : "Ovarian tissue collected before oncological treatment",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-reproductive-tissue"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "BiologicallyDerivedProduct"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "BiologicallyDerivedProduct-ovariantissue1-1.html"
      }],
      "reference" : {
        "reference" : "BiologicallyDerivedProduct/ovariantissue1-1"
      },
      "name" : "ovariantissue1-1",
      "description" : "Package 1 of 2 - cryopreserved, in storage",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-reproductive-tissue"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-package.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-package"
      },
      "name" : "Package",
      "description" : "Extension for packaging separate embryos in one package intended to be transferred at the same time. (ee Pakend erinevate embrüote üheaegseks siirdamiseks.)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-donor-anonymous.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-donor-anonymous"
      },
      "name" : "Patient: EE VRIS Anonymous Patient",
      "description" : "Anonymous donor in the Estonian VRIS fertility system. (ee Anonüümne (välismaa) doonor VRIS-is.)",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-patient-child.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-patient-child"
      },
      "name" : "Patient: EE VRIS Child",
      "description" : "Child born from VRIS fertility treatment. (ee VRIS viljatusravi tulemusena sündinud laps. ISIKUKOOD teada!)",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-patient-child-unknown-id.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-patient-child-unknown-id"
      },
      "name" : "Patient: EE VRIS Child ID Unknown",
      "description" : "Child born from VRIS fertility treatment with UNKNOWN ID (and NO name) Identifier is generated by HC provider. (ee VRIS viljatusravi tulemusena sündinud laps. ISIKUKOOD teadMATA! IK genereeritud TTO poolt.)",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-donor.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-donor"
      },
      "name" : "Patient: EE VRIS Donor",
      "description" : "For use of donors. (ee Doonori profiil, kasutamiseks. Anonüümsete ja anonüümsete-välismaiste doonorite puhul on TEINE PROFIIL!)",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-patient-universal.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-patient-universal"
      },
      "name" : "Patient: EE VRIS Patient",
      "description" : "VRIS patient profile. (ee EI KASUTA! VRIS patsiendi profiil. Roll modifierExtension'ina ning link viitab MPI ametlikule patsiendikirjele.)",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-recipient.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-recipient"
      },
      "name" : "Patient: EE VRIS Recipient",
      "description" : "For use of patients who recieve care and are recipients of biologic material. (ee retsipienti profiil. NB! alati MPI-s registreeritud. NB! Kas partner on retsipient?)",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-patientChild1.html"
      }],
      "reference" : {
        "reference" : "Patient/patientChild1"
      },
      "name" : "patientChild1",
      "description" : "Example of child born from VRIS fertility treatment",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-patient-child"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-patientDonorMale.html"
      }],
      "reference" : {
        "reference" : "Patient/patientDonorMale"
      },
      "name" : "patientDonorMale",
      "description" : "Example of known Estonian male sperm donor",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-donor"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-patientDonorunknown1.html"
      }],
      "reference" : {
        "reference" : "Patient/patientDonorunknown1"
      },
      "name" : "patientDonorunknown1",
      "description" : "Example of anonymous foreign sperm donor",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-donor-anonymous"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-patientFemale.html"
      }],
      "reference" : {
        "reference" : "Patient/patientFemale"
      },
      "name" : "patientFemale",
      "description" : "Example of verified female patient",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-practitioner-doctor.html"
      }],
      "reference" : {
        "reference" : "Practitioner/practitioner-doctor"
      },
      "name" : "practitioner-doctor",
      "description" : "Example of Practitioner D99876",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-practitionerrole-doctor.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/practitionerrole-doctor"
      },
      "name" : "practitionerrole-doctor",
      "description" : "Example of doctor (PractitionerRole D99876) working at NovaVita",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-procedure-cryoSperm1.html"
      }],
      "reference" : {
        "reference" : "Procedure/procedure-cryoSperm1"
      },
      "name" : "procedure-cryoSperm1",
      "description" : "Cryopreservation of two sperm packages",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-procedure-cryopreservation"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-procedure-donationSperm1.html"
      }],
      "reference" : {
        "reference" : "Procedure/procedure-donationSperm1"
      },
      "name" : "procedure-donationSperm1",
      "description" : "Sperm donation procedure",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-procedure-donation"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-procedure-embryo-transfer.html"
      }],
      "reference" : {
        "reference" : "Procedure/procedure-embryo-transfer"
      },
      "name" : "procedure-embryo-transfer",
      "description" : "Example of fresh embryo transfer procedure",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-procedure-embryo-transfer"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-procedure-fertilization1.html"
      }],
      "reference" : {
        "reference" : "Procedure/procedure-fertilization1"
      },
      "name" : "procedure-fertilization1",
      "description" : "Example of IVF fertilization procedure using donor sperm",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-procedure-fertilization"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-procedure-oocyte-retrieval.html"
      }],
      "reference" : {
        "reference" : "Procedure/procedure-oocyte-retrieval"
      },
      "name" : "procedure-oocyte-retrieval",
      "description" : "Example of oocyte retrieval procedure in IVF cycle March 2025",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-procedure-oocyte-retrieval"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-procedure-allocation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-procedure-allocation"
      },
      "name" : "Procedure: EE VRIS Allocation",
      "description" : "Profile for allocation of biological material (sperm, oocyte, embryo reproductive tissue). (ee Bioloogilise materjali broneerimise protseduur. Kasutada juhul kui annetatud bioloogiline materjal on kindlale retsipiendidle broneeritud.)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-procedure-cryopreservation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-procedure-cryopreservation"
      },
      "name" : "Procedure: EE VRIS Cryopreservation",
      "description" : "Profile for cryopreservation of biological material (sperm, oocyte, embryo). (ee Bioloogilise materjali külmutamise protseduur. )",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-procedure-destruction.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-procedure-destruction"
      },
      "name" : "Procedure: EE VRIS Destruction",
      "description" : "Profile for destruction of biological material (sperm, oocyte, embryo, reproductive tissue). (ee Bioloogilise materjali hävitamise protseduur.)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-procedure-donation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-procedure-donation"
      },
      "name" : "Procedure: EE VRIS Donation",
      "description" : "Profile for donation of biological material (sperm, oocyte, reproductive tissue). (ee Bioloogilise materjali annetamise JA/või KOGUMISE protseduur.)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-procedure-embryo-transfer.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-procedure-embryo-transfer"
      },
      "name" : "Procedure: EE VRIS Embryo Transfer",
      "description" : "Procedure for embryo transfer to recipient. Records transfer date, number of embryos, outcome, or reason for non-transfer. (ee Embrüo siirdamise protseduur.)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-procedure-fertilization.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-procedure-fertilization"
      },
      "name" : "Procedure: EE VRIS Fertilization",
      "description" : "Profile for oocyte fertilization procedure using IVF, ICSI, or both methods. (ee Munarakkude viljastamise protseduur.)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-procedure-insemination.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-procedure-insemination"
      },
      "name" : "Procedure: EE VRIS Intrauterine Insemination (IUI)",
      "description" : "Profile for intrauterine insemination procedure sperm directly introduced into the uterine cavity. (ee Emakasisene inseminatsioon (IUI).)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-procedure-oocyte-retrieval.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-procedure-oocyte-retrieval"
      },
      "name" : "Procedure: EE VRIS Oocyte Retrieval",
      "description" : "Profile for oocyte retrieval (ovarian puncture) procedure. (ee Munasarjade punktsioon, munarakkude saamise protseduur.)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-procedure-pgt.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-procedure-pgt"
      },
      "name" : "Procedure: EE VRIS Preimplantation Genetic Testing",
      "description" : "Procedure for preimplantation genetic testing (PGT) of embryos. (ee Embrüodiagnostika protseduur enne siirdamist.)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-procedure.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-procedure"
      },
      "name" : "Procedure: EE VRIS Procedure",
      "description" : "Base profile for Procedure. For each specific procedure use their profiles(freezing, destroying, donating, dispensing etc)... (ee Baasprofiil erinevate protseduuride kirjeldamiseks. (Nt. Külmutamine, annetamine...))",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-recryo.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-recryo"
      },
      "name" : "Re-cryopreservation date and count",
      "description" : "Extension for re-cryopreservation information. (ee Bioloogilise materjali taaskülmutamine ja arv.)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-related-clinic.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-related-clinic"
      },
      "name" : "Related clinic",
      "description" : "Extension for related (fertility) clinic who has more rights to see their patient data. (ee Patsiendiga seotud (viljatusravikliinik)/TTO)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-donor-reference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-donor-reference"
      },
      "name" : "Related person reference",
      "description" : "Extension for referencing related person. (ee Viide seotud isikule/doonorile.)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-related-person.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-related-person"
      },
      "name" : "RelatedPerson: EE VRIS RelatedPerson",
      "description" : "Related person profile for VRIS. (ee Seotud isiku profiil näitab seost patsiendi või retsipiendiga. Doonori ja retsipiendi vahelise SUHTE kirjeldus.)",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "BiologicallyDerivedProduct"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "BiologicallyDerivedProduct-sperm1.html"
      }],
      "reference" : {
        "reference" : "BiologicallyDerivedProduct/sperm1"
      },
      "name" : "sperm1",
      "description" : "Example of donor sperm",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-sperm"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "BiologicallyDerivedProduct"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "BiologicallyDerivedProduct-sperm1-1.html"
      }],
      "reference" : {
        "reference" : "BiologicallyDerivedProduct/sperm1-1"
      },
      "name" : "sperm1-1",
      "description" : "Package 1 of 3 - used fresh",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-sperm"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "BiologicallyDerivedProduct"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "BiologicallyDerivedProduct-sperm1-2.html"
      }],
      "reference" : {
        "reference" : "BiologicallyDerivedProduct/sperm1-2"
      },
      "name" : "sperm1-2",
      "description" : "Package 2 of 3 - cryopreserved, available",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-sperm"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "BiologicallyDerivedProduct"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "BiologicallyDerivedProduct-sperm1-3.html"
      }],
      "reference" : {
        "reference" : "BiologicallyDerivedProduct/sperm1-3"
      },
      "name" : "sperm1-3",
      "description" : "Package 3 of 3 - cryopreserved, available",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-sperm"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-stimulation-method.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-stimulation-method"
      },
      "name" : "Stimulation method",
      "description" : "Extension for describing which stimulation method is/was used. (ee Bioloogilise materjali stimulatsiooni meetod.)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-supply-delivery.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-supply-delivery"
      },
      "name" : "SupplyDelivery: EE VRIS Biological material movement",
      "description" : "Use this profile for describing when the biological material (sperm, oocyte, embryo) is transferred from one place to another. (ee Eestis annetatud bioloogiline materjali (sperma, munarakud, embrüo) liikumine TTO-sse/sealt välja",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SupplyDelivery"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SupplyDelivery-supplyDeliverySperm1.html"
      }],
      "reference" : {
        "reference" : "SupplyDelivery/supplyDeliverySperm1"
      },
      "name" : "supplyDeliverySperm1",
      "description" : "Example of sperm package delivery from Nova Vita to PERH, 4 doses of donor sperm",
      "isExample" : true,
      "profile" : ["https://fhir.ee/vris/StructureDefinition/ee-vris-supply-delivery"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ee-vris-thawing.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ee-vris-thawing"
      },
      "name" : "Thawing date and count",
      "description" : "Extension for thawing information. (ee Bioloogilise materjali sulatamise kuupäev ja arv.)",
      "isExample" : false
    }],
    "page" : {
      "sourceUrl" : "toc.html",
      "name" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "sourceUrl" : "index.html",
        "name" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "page1.html",
        "name" : "page1.html",
        "title" : "Diagram examples",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "page2.html",
        "name" : "page2.html",
        "title" : "Sample page 2",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "downloads.html",
        "name" : "downloads.html",
        "title" : "Downloads",
        "generation" : "html"
      },
      {
        "sourceUrl" : "contacts.html",
        "name" : "contacts.html",
        "title" : "Contacts",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "search.html",
        "name" : "search.html",
        "title" : "Search",
        "generation" : "html"
      }]
    },
    "parameter" : [{
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "copyrightyear"
      },
      "value" : "2025+"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "releaselabel"
      },
      "value" : "draft"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "excludettl"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "validation"
      },
      "value" : "allow-any-extensions"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "show-inherited-invariants"
      },
      "value" : "false"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "autoload-resources"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/capabilities"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/examples"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/extensions"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/models"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/operations"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/profiles"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/resources"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/vocabulary"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/maps"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/testing"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/history"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "fsh-generated/resources"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-pages"
      },
      "value" : "template/config"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-pages"
      },
      "value" : "input/images"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-liquid"
      },
      "value" : "template/liquid"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-liquid"
      },
      "value" : "input/liquid"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-qa"
      },
      "value" : "temp/qa"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-temp"
      },
      "value" : "temp/pages"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-output"
      },
      "value" : "output"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-tx-cache"
      },
      "value" : "input-cache/txcache"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-suppressed-warnings"
      },
      "value" : "input/ignoreWarnings.txt"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-history"
      },
      "value" : "https://fhir.ee/vris/history.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "template-html"
      },
      "value" : "template-page.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "template-md"
      },
      "value" : "template-page-md.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-contact"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-context"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-copyright"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-jurisdiction"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-license"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-publisher"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-version"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-wg"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "active-tables"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "fmm-definition"
      },
      "value" : "http://hl7.org/fhir/versions.html#maturity"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "propagate-status"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "excludelogbinaryformat"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "tabbed-snapshots"
      },
      "value" : "true"
    }]
  }
}

```
